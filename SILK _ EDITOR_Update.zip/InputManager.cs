using Silk.NET.Input;

public class InputManager
{
    
}